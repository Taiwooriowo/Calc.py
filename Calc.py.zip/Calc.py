import math
num1 = float(input('What is your first number?: '))
op = input('Pick an operator: ')
num2 = float(input('What is your second number?: '))

if op == '+':
    print(round(num1 + num2, 2))
elif op == '-':
    print(round(num1 - num2, 2))
elif op == '*':
    print(round(num1 * num2, 2))
elif op == '/':
    print(round(num1 / num2, 2))
elif op == '**':
    print(round(num1 ** num2, 2))
elif op == 's':
    print(round(math.sqrt(num1), 2))
else:
    print('invalid operator')